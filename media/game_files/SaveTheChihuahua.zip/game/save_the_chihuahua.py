import pygame
import sys
import random
import os

# 実行ファイル内でのアセットパス取得
def resource_path(relative_path):
    try:
        # PyInstallerでバンドルされた場合
        base_path = sys._MEIPASS
    except Exception:
        # 開発環境でのパス（ファイルが直接存在する場合）
        base_path = os.path.dirname(__file__)
    
    return os.path.join(base_path, relative_path)

# Pygameの初期化
pygame.init()
pygame.mixer.init()

# assets フォルダのパスを動的に取得
asset_path = resource_path("assets")

# 画面サイズの設定
screen_width = 300
screen_height = 600

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Save The Chihuahua')

# 色の定義
BLACK = (0, 0, 0)
WHITE = (200, 200, 200)

# ハートの画像を読み込む
heart_full = pygame.image.load(resource_path('assets/hert.png')).convert_alpha()
heart_empty = pygame.image.load(resource_path('assets/hert2.png')).convert_alpha()

# たすけたチワワの画像を読み込む
saved_image = pygame.image.load(resource_path('assets/saved2.png')).convert_alpha()

# プレイヤークラスの定義
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # 右向きの画像を読み込む
        self.image_right = pygame.image.load(resource_path('assets/poison3.png')).convert_alpha()
        # 左向きの画像を読み込む
        self.image_left = pygame.image.load(resource_path('assets/poison2.png')).convert_alpha()
        # 静止時の画像を読み込む
        self.image_static = pygame.image.load(resource_path('assets/poison.png')).convert_alpha()
        self.image = self.image_static  # 初期は静止時の画像を表示
        self.rect = self.image.get_rect()
        self.rect.center = (screen_width // 2, 550)  # 初期位置
        self.speed = 5  # 移動速度
        self.is_right_pressed = False  # 右キーが押されているかどうかのフラグ
        self.is_left_pressed = False  # 左キーが押されているかどうかのフラグ
        self.is_dash = False
        self.lives = 3  # ライフの初期値

    def update(self):
        # プレイヤーの移動や他の更新ロジックをここに追加する場合
        if self.is_right_pressed:
            self.move_right()
        elif self.is_left_pressed:
            self.move_left()
        else:
            self.image = self.image_static

    def move_right(self):
        self.image = self.image_right  # 右向きの画像を表示
        if self.is_dash:
            self.rect.x += self.speed + 5
        else:
            self.rect.x += self.speed  # 右に移動
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > screen_width:
            self.rect.right = screen_width

    def move_left(self):
        self.image = self.image_left  # 左向きの画像を表示
        if self.is_dash:
            self.rect.x -= self.speed + 5
        else:
            self.rect.x -= self.speed  # 左に移動
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > screen_width:
            self.rect.right = screen_width

    def shoot(self):
        bullet = Bullet(self.rect.centerx, self.rect.centery)
        return bullet

    def decrease_life(self):
        self.lives -= 1

    def draw_lives(self, screen):
        heart_spacing = 5
        heart_size = heart_full.get_width()
        x = 10
        y = 10
        for i in range(self.lives):
            screen.blit(heart_full, (x + i * (heart_size + heart_spacing), y))
        for i in range(self.lives, 3):
            screen.blit(heart_empty, (x + i * (heart_size + heart_spacing), y))

# 弾のクラス
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load(resource_path('assets/ster2.png')).convert_alpha()  # 弾の画像を読み込む
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)  # 弾の初期位置をプレイヤーの位置に設定
        self.speed = 10  # 弾の速度

    def update(self):
        self.rect.y -= self.speed  # 上に移動
        # 画面外に出たら消去するなどの処理をここに追加する

# 敵のクラス
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load(resource_path('assets/enemy.png')).convert_alpha()  # 敵の画像を読み込む
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, screen_width - self.rect.width)
        self.rect.y = random.randint(-screen_height, -self.rect.height)
        self.speed = random.randint(3, 7)  # 敵の移動速度

    def update(self):
        self.rect.y += self.speed  # 下に移動
        if self.rect.top > screen_height:  # 画面外に出たら再配置する
            self.rect.x = random.randint(0, screen_width - self.rect.width)
            self.rect.y = random.randint(-screen_height, -self.rect.height)
            self.speed = random.randint(3, 7)

# ゲームのメイン処理
def main():
    # プレイヤーオブジェクトの作成
    player = Player()

    # 弾のグループ
    bullets = pygame.sprite.Group()

    # 敵のグループ
    enemies = pygame.sprite.Group()

    # ゲームオーバーのフォント
    gameover_font = pygame.font.Font(None, 36)

    # 撃破した敵の数
    enemies_destroyed = 0

    # ゲームループ
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RIGHT:
                    player.is_right_pressed = True
                elif event.key == pygame.K_LEFT:
                    player.is_left_pressed = True
                elif event.key == pygame.K_SPACE:
                    player.is_dash = True
                    bullet = player.shoot()
                    bullets.add(bullet)

            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_RIGHT:
                    player.is_right_pressed = False
                elif event.key == pygame.K_LEFT:
                    player.is_left_pressed = False
                elif event.key == pygame.K_SPACE:
                    player.is_dash = False

        # 画面を塗りつぶす
        screen.fill(BLACK)

        # プレイヤーの更新
        player.update()

        # 弾の更新
        bullets.update()

        # 敵の更新と描画
        for enemy in enemies:
            enemy.update()
            screen.blit(enemy.image, enemy.rect)
            # 敵が画面最下部に触れたらライフを減らす
            if enemy.rect.bottom >= screen_height:
                player.decrease_life()
                enemies.remove(enemy)

        # プレイヤーと弾を描画
        screen.blit(player.image, player.rect)
        for bullet in bullets:
            screen.blit(bullet.image, bullet.rect)

        # ライフを描画
        player.draw_lives(screen)

        # たすけたちわわを描写
        screen.blit(saved_image, (screen_width - saved_image.get_width() - 25, 5))

        # 撃破した敵の数を表示
        enemies_destroyed_text = gameover_font.render(f'{enemies_destroyed}', True, WHITE)
        screen.blit(enemies_destroyed_text, (screen_width - enemies_destroyed_text.get_width() - 10, 15))

        # 一定の間隔で新しい敵を生成
        if random.randint(1, 15) == 1:
            new_enemy = Enemy()
            new_enemy.rect.x = random.randint(0, screen_width - new_enemy.rect.width)
            enemies.add(new_enemy)

        # 弾と敵の衝突判定
        for bullet in bullets:
            hits = pygame.sprite.spritecollide(bullet, enemies, True)
            for hit in hits:
                bullets.remove(bullet)
                enemies_destroyed += 1

        # プレイヤーのライフが0以下になったらゲームオーバー
        if player.lives <= 0:
            gameover_text = gameover_font.render('Game Over', True, WHITE)
            screen.blit(gameover_text, (screen_width // 2 - gameover_text.get_width() // 2, screen_height // 2 - gameover_text.get_height() // 2))
            pygame.display.update()
            pygame.time.delay(4000)  # ゲームオーバー後の待機時間
            running = False

        # 画面更新
        pygame.display.update()

        # フレームごとの処理時間を制限
        pygame.time.Clock().tick(30)

    # Pygameの終了
    pygame.quit()
    sys.exit()

# ゲームのメイン処理を実行する条件
if __name__ == "__main__":
    main()
